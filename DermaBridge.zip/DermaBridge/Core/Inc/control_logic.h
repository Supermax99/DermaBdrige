/*
 * control_logic.h
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

#ifndef DERMABRIDGE_INC_CONTROL_LOGIC_H_
#define DERMABRIDGE_INC_CONTROL_LOGIC_H_

//

#include "wb.h"
#include "pot_com.h"
#include "ina.h"
#include "swg.h"

//
#define DELTA_R 100
#define DEFAULT_AMPLITUDE 1
#define DEFUALT_RESISTANCE 1

//
typedef enum
{
	CHECK_EQUILIBRIUM = 0,
    CONTROL_EQUILBRIUM
}db_state_t;

typedef struct
{
  float model_measured_resistance; //calculated resistance using the math model of the circuit
  float lkt_measured_resistance; //calculated resistance based on lookup table method
  float measured_resistance; //resistance measured with decreasing resistance approach

  float current_ina_gain; //current_ina_gain
  float current_amplitude; //current_amplitude of the sine wave

  double phase_bit;

}var_struct_t;

extern db_state_t db_state;
extern var_struct_t var_struct;
extern uint32_t sampled_value[1];

//
void control_logic(void);
void circuit_test(void);
void circuit_init(ADC_HandleTypeDef *adc, DAC_HandleTypeDef *dac, TIM_HandleTypeDef *dactim,
		TIM_HandleTypeDef *bitim, TIM_HandleTypeDef *adctim, SPI_HandleTypeDef *spi, float amplitude);
#endif /* DERMABRIDGE_INC_CONTROL_LOGIC_H_ */
