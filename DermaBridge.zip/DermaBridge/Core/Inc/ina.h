/*
 * ina.h
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

#ifndef DERMABRIDGE_INC_INA_H_
#define DERMABRIDGE_INC_INA_H_

/**/
#include "pot_com.h"

/**/
#define LOW_INA_GAIN 1.5
/**/
extern float ina_gain;

/**/
void set_ina_gain(float gain);
#endif /* DERMABRIDGE_INC_INA_H_ */
