/*
 * pot_com.h
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

#ifndef DERMABRIDGE_INC_POT_COM_H_
#define DERMABRIDGE_INC_POT_COM_H_

/*include*/
#include "main.h"
#include "stdbool.h"

/*define*/
#define POT_CALIBRATION  1
#define RDAC_UPDATE_ENBL 0b0000000000000010
#define RDAC_LOCK        0b0000000000000000
#define PERF_MODE        0b0000000000000000
#define NORMAL_MODE      0b0000000000000100
#define INA819           0
#define AD5293           1
/*typedef & extern*/

typedef enum
{
	NOP_COMMAND = 0b0000000000000000,
	WRITE_RDAC = 0b0000010000000000,
	READ_FROM_RDAC = 0b00100000000000,
	RESET_RDAC = 0b001000000000000,
	SET_CTRL_BITS = 0b0001100000000000,
	READ_CTRL_BITS = 0b0001110000000000,
	POWER_CTRL_DEVICE = 0b0010000000000000
}dpot_cmd_t;

typedef enum
{
	DPOT_NOT_OK = 0,
	DPOT_OK,
	DPOT_WRONG_VALUE,
}dpt_status_t;

extern dpt_status_t ina_dpt_status;
extern dpt_status_t wb_dpt_status;

/**/

dpt_status_t initialize_dpt(SPI_HandleTypeDef *hspi);
dpt_status_t write_rdac(uint16_t data, bool device);
dpt_status_t write_ctrl_bits(uint16_t data, bool device);
dpt_status_t set_dpot_cmd(dpot_cmd_t cmd, uint16_t data, bool device);
#endif /* DERMABRIDGE_INC_POT_COM_H_ */
