/*
 * swg.h
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

#ifndef DERMABRIDGE_INC_SWG_H_
#define DERMABRIDGE_INC_SWG_H_

/*Include*/
#include "stm32f4xx_hal.h"

/*define*/
#define SINE_CALIBRATION 0

#define R1 1020.f
#define R2 820.f
#define R3 1015.f
#define R4 8232.f
#define NS_SAMPLE 1025
#define MAX_DAC_VALUE 4095
#define SINE_OFFSET 215
#define DC_OFFSET 300
#define CAL_SIZE 19

#define V_REF_DAC 3.3
/*typedef & extern*/

typedef enum
{
	SINE_WAVE_ERROR = 0,
	SINE_WAVE_OK
}swg_status_t;


typedef struct
{
	float amplitude;
	uint16_t sine_offset;
	uint16_t dc_offset;
}cal_struct_t;

extern float target_amplitude;
extern swg_status_t swg_status;
extern uint8_t sine_freq;
extern float target_amplitude;
extern uint32_t k_scaled_sine_wave[NS_SAMPLE];
extern uint32_t digital_sine_wave[NS_SAMPLE];


/*function declaration*/

void set_amplitude(float amplitude);
void set_sine_freq(uint8_t freq);
swg_status_t set_dac_dma(DAC_HandleTypeDef *dac, TIM_HandleTypeDef * htim);

#endif /* DERMABRIDGE_INC_SWG_H_ */
