/*
 * wb.h
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

#ifndef DERMABRIDGE_INC_WB_H_
#define DERMABRIDGE_INC_WB_H_

//
#include "pot_com.h"

//
#define LOW_MUX_SIZE 9
#define HIGH_MUX_SIZE 5
#define R_AB_WB 100000

//
typedef enum
{
  H_POSITION_0 = 0,
  POSITION_1M,   //1
  POSITION_1M78, //2
  POSITION_3M,   //3
  POSITION_4M02, //4
  POSITION_4M99, //5
}high_mux_pos_t;

typedef enum
{
	L_POSITION_0 = 0,
	POSITION_100K, //1
	POSITION_200K, //2
	POSIITON_300K, //3
	POSITION_402K, //4
	POSITION_499K, //5
	POSITION_604K, //6
	POSITION_698K, //7
	POSITION_806K, //8
	POSITION_909K, //9
}low_mux_pos_t;


extern float current_resistance;
//
void set_rwb_resistance(float resistance);
void set_low_mux(low_mux_pos_t position);
void set_high_mux(high_mux_pos_t position);
void phasebit_calculation(void);
#endif /* DERMABRIDGE_INC_WB_H_ */
