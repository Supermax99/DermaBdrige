/*
 * control_logic.c
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

#include "control_logic.h"

db_state_t db_state = 	CHECK_EQUILIBRIUM;
uint16_t digital_value = 0;
uint32_t sampled_value[1];

void phase_bit_control_logic(void) {
	switch(db_state)
	{
	case CHECK_EQUILIBRIUM:
		/*here it set the resistance */
	    break;
	case CONTROL_EQUILBRIUM:
		break;
	}
}

                  /* 1) adc for sampling   2) dac  3) tim for dac 4) tim for bit di fase 5) tim for adc 6) spi per digipot   */
void circuit_init(ADC_HandleTypeDef *adc, DAC_HandleTypeDef *dac, TIM_HandleTypeDef *dactim,
		TIM_HandleTypeDef *bitim, TIM_HandleTypeDef *adctim, SPI_HandleTypeDef *spi, float amplitude)
{
	/*set the SWG block*/

	set_dac_dma(dac, dactim); //set dma and dac
	set_amplitude(amplitude); //by default the amplitude is 1

	/*set timer for phase bit calculation*/

	HAL_TIM_Base_Start_IT(bitim);

	/*timer for adc sampling freq*/

	HAL_TIM_Base_Start(adctim);

	/*set wb and ina*/

	initialize_dpt(spi); //spi for comunication with digipot

    /*set adc with dma for sampling data*/

	HAL_ADC_Start_DMA(adc, (uint32_t*)&sampled_value[0], 1);

	/*here it set the initial value wb and ins*/

    set_rwb_resistance(current_resistance); //set default resistance of digipot wb
     set_ina_gain(LOW_INA_GAIN); //set lower gain for ina819
}

void circuit_test(void) {

	/*section for swg circuit*/
	target_amplitude = 1;
	set_amplitude(target_amplitude);
	/**/
	set_high_mux(H_POSITION_0);
	set_low_mux(L_POSITION_0);

	/**/
	uint16_t digital_ina = 1000;

	/**/
	write_rdac(digital_value, AD5293);
	write_rdac(digital_ina, INA819);

	/**/
	while (1) {
		/**/
		digital_value++;
		if (digital_value > 1024) {
			digital_value = 0;
		}
		write_rdac(digital_value, AD5293);
        HAL_Delay(50);
	}
}
