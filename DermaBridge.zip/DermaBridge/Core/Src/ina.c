/*
 * ina.c
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

#include "ina.h"

float ina_gain;

void set_ina_gain(float gain)
{
	uint16_t digit_value = 0;
	digit_value = (3072 - 2*gain*1024)/(2-2*gain);

	ina_dpt_status = write_rdac(digit_value, INA819);
}
