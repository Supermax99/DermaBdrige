/*
 * pot_com.c
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */

/*include*/
#include "pot_com.h"
/*variable definition*/

dpt_status_t ina_dpt_status;
dpt_status_t wb_dpt_status;
SPI_HandleTypeDef *spi;

/*function definition*/
static inline void cs_ina_low(void) {
	LL_GPIO_ResetOutputPin(INA_CS_PIN_GPIO_Port, INA_CS_PIN_Pin);
} //set pin

static inline void cs_ina_high(void) {
	LL_GPIO_SetOutputPin(INA_CS_PIN_GPIO_Port, INA_CS_PIN_Pin);
} //set pin

static inline void cs_wb_dpt_low(void) {
	LL_GPIO_ResetOutputPin(WB_CS_PIN_GPIO_Port, WB_CS_PIN_Pin);
}  //set pin

static inline void cs_wb_dpt_high(void) {
	LL_GPIO_SetOutputPin(WB_CS_PIN_GPIO_Port, WB_CS_PIN_Pin);
} // set pin

dpt_status_t set_dpot_cmd(dpot_cmd_t cmd, uint16_t data, bool device) {

	uint16_t buffer = cmd | data;
	uint8_t datatosend[2];
	datatosend[0] = (uint8_t)( buffer >> 8);
	datatosend[1] = (uint8_t)(0b0000000011111111 & buffer);
	HAL_StatusTypeDef status = HAL_OK;
	switch (device) {
	case INA819: {
		cs_ina_low();
		status = HAL_SPI_Transmit(spi, (uint8_t*) &datatosend[0], 2, HAL_MAX_DELAY);
		cs_ina_high();
		if (status == HAL_OK) {
			return DPOT_OK;
		} else
			return DPOT_NOT_OK;
	}
	case AD5293: {
		cs_wb_dpt_low();
		status = HAL_SPI_Transmit(spi, (uint8_t*) &datatosend[0], 2, HAL_MAX_DELAY);
		cs_wb_dpt_high();
		if (status == HAL_OK) {
			return DPOT_OK;
		} else
			return DPOT_NOT_OK;
	}
	}
	return 1;
}

dpt_status_t initialize_dpt(SPI_HandleTypeDef *hspi) {
	//
	spi = hspi;
	uint16_t buffer = PERF_MODE | RDAC_UPDATE_ENBL;
	//uint16_t buffer = 0x1802;

	dpt_status_t status = DPOT_OK;
	//
	status = set_dpot_cmd(SET_CTRL_BITS, buffer, INA819);
	status = set_dpot_cmd(SET_CTRL_BITS, buffer, AD5293);
	return status;

}
//TODO: da testare
dpt_status_t write_rdac(uint16_t data, bool device) {
	//
	uint16_t buffer = WRITE_RDAC | data;
	dpt_status_t status = DPOT_OK;

	//
	if ((set_dpot_cmd(WRITE_RDAC, buffer, device) == DPOT_OK)) {
		HAL_Delay(1);
		status = set_dpot_cmd(READ_FROM_RDAC, 0x0000, device);
	}
	//set_dpot_cmd(NOP_COMMAND, 0x0000, device);

	return status;

}
