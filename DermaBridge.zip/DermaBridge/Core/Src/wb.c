/*
 * wb.c
 *
 *  Created on: Apr 9, 2024
 *      Author: supermax
 */
#include "wb.h"
#include "stdbool.h"
const uint32_t high_mux[HIGH_MUX_SIZE] = { 1000000, 1780000, 3000000, 4020000,
		4990000 };
const uint32_t low_mux[LOW_MUX_SIZE] = { 100000, 200000, 300000, 402000, 499000,
		604000, 698000, 806000, 909000 };
float current_resistance;
bool h_pos0, pos1m, pos1m78, pos3, pos4m02, pos4m99, l_pos0, pos110k, pos200k,
		pos300k, pos402k, pos499k, pos604k, pos698k, pos808k, pos909k;
bool h_check_bit, l_check_bit;
uint16_t digital_pot_value;
float digital_resistance;
int8_t h_i, l_i;

/*phase bit*/
bool input1_flag;
uint8_t input1;
uint8_t input2;
uint8_t xor;
uint8_t xor_array[XOR_SIZE];
double xor_mean;
uint8_t i;
/**/
double calculateMean(uint8_t arr[], int size) {
	int sum = 0;
	for (int i = 0; i < size; i++) {
		sum += arr[i];
	}
	return (double) sum / size;
}
void set_high_mux(high_mux_pos_t position) {
	switch (position) {

	case H_POSITION_0:
		h_pos0 = true;
		pos1m = false;
		pos1m78 = false;
		pos3 = false;
		pos4m02 = false;
		pos4m99 = false;
		LL_GPIO_ResetOutputPin(MUX_CS4_GPIO_Port, MUX_CS4_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS5_GPIO_Port, MUX_CS5_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS6_GPIO_Port, MUX_CS6_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS7_GPIO_Port, MUX_CS7_Pin); //0
		break;

	case POSITION_1M:
		h_pos0 = false;
		pos1m = true;
		pos1m78 = false;
		pos3 = false;
		pos4m02 = false;
		pos4m99 = false;
		LL_GPIO_SetOutputPin(MUX_CS4_GPIO_Port, MUX_CS4_Pin); //1
		LL_GPIO_ResetOutputPin(MUX_CS5_GPIO_Port, MUX_CS5_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS6_GPIO_Port, MUX_CS6_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS7_GPIO_Port, MUX_CS7_Pin); //0
		break;

	case POSITION_1M78:
		h_pos0 = false;
		pos1m = false;
		pos1m78 = true;
		pos3 = false;
		pos4m02 = false;
		pos4m99 = false;
		LL_GPIO_ResetOutputPin(MUX_CS4_GPIO_Port, MUX_CS4_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS5_GPIO_Port, MUX_CS5_Pin); //1
		LL_GPIO_ResetOutputPin(MUX_CS6_GPIO_Port, MUX_CS6_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS7_GPIO_Port, MUX_CS7_Pin); //0
		break;

	case POSITION_3M:
		h_pos0 = false;
		pos1m = false;
		pos1m78 = false;
		pos3 = true;
		pos4m02 = false;
		pos4m99 = false;
		LL_GPIO_SetOutputPin(MUX_CS4_GPIO_Port, MUX_CS4_Pin); //1
		LL_GPIO_SetOutputPin(MUX_CS5_GPIO_Port, MUX_CS5_Pin); //1
		LL_GPIO_ResetOutputPin(MUX_CS6_GPIO_Port, MUX_CS6_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS7_GPIO_Port, MUX_CS7_Pin); //0
		break;

	case POSITION_4M02:
		h_pos0 = false;
		pos1m = false;
		pos1m78 = false;
		pos3 = false;
		pos4m02 = true;
		pos4m99 = false;
		LL_GPIO_ResetOutputPin(MUX_CS4_GPIO_Port, MUX_CS4_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS5_GPIO_Port, MUX_CS5_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS6_GPIO_Port, MUX_CS6_Pin);  //1
		LL_GPIO_ResetOutputPin(MUX_CS7_GPIO_Port, MUX_CS7_Pin); //0
		break;

	case POSITION_4M99:
		h_pos0 = false;
		pos1m = false;
		pos1m78 = false;
		pos3 = false;
		pos4m02 = false;
		pos4m99 = true;
		LL_GPIO_SetOutputPin(MUX_CS4_GPIO_Port, MUX_CS4_Pin); //1
		LL_GPIO_ResetOutputPin(MUX_CS5_GPIO_Port, MUX_CS5_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS6_GPIO_Port, MUX_CS6_Pin);  //1
		LL_GPIO_ResetOutputPin(MUX_CS7_GPIO_Port, MUX_CS7_Pin); //0
		break;
	}

}

void set_low_mux(low_mux_pos_t position) {
	switch (position) {

	case L_POSITION_0:
		l_pos0 = true;
		pos110k = false;
		pos200k = false;
		pos300k = false;
		pos402k = false;
		pos499k = false;
		pos604k = false;
		pos698k = false;
		pos808k = false;
		pos909k = false;
		LL_GPIO_ResetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSITION_100K:
		l_pos0 = false;
		pos110k = true;
		pos200k = false;
		pos300k = false;
		pos402k = false;
		pos499k = false;
		pos604k = false;
		pos698k = false;
		pos808k = false;
		pos909k = false;
		LL_GPIO_SetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSITION_200K:
		l_pos0 = false;
		pos110k = false;
		pos200k = true;
		pos300k = false;
		pos402k = false;
		pos499k = false;
		pos604k = false;
		pos698k = false;
		pos808k = false;
		pos909k = false;
		LL_GPIO_ResetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSIITON_300K:
		l_pos0 = false;
		pos110k = false;
		pos200k = false;
		pos300k = true;
		pos402k = false;
		pos499k = false;
		pos604k = false;
		pos698k = false;
		pos808k = false;
		pos909k = false;
		LL_GPIO_SetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin);   //1
		LL_GPIO_SetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSITION_402K:
		l_pos0 = false;
		pos110k = false;
		pos200k = false;
		pos300k = false;
		pos402k = true;
		pos499k = false;
		pos604k = false;
		pos698k = false;
		pos808k = false;
		pos909k = false;
		LL_GPIO_ResetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSITION_499K:
		l_pos0 = false;
		pos110k = false;
		pos200k = false;
		pos300k = false;
		pos402k = false;
		pos499k = true;
		pos604k = false;
		pos698k = false;
		pos808k = false;
		pos909k = false;
		LL_GPIO_SetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSITION_604K:
		l_pos0 = false;
		pos110k = false;
		pos200k = false;
		pos300k = false;
		pos402k = false;
		pos499k = false;
		pos604k = true;
		pos698k = false;
		pos808k = false;
		pos909k = false;
		LL_GPIO_ResetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin);   //1
		LL_GPIO_SetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSITION_698K:
		l_pos0 = false;
		pos110k = false;
		pos200k = false;
		pos300k = false;
		pos402k = false;
		pos499k = false;
		pos604k = false;
		pos698k = true;
		pos808k = false;
		pos909k = false;
		LL_GPIO_SetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin);   //1
		LL_GPIO_SetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin);   //1
		LL_GPIO_SetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin); //0
		break;

	case POSITION_806K:
		l_pos0 = false;
		pos110k = false;
		pos200k = false;
		pos300k = false;
		pos402k = false;
		pos499k = false;
		pos604k = false;
		pos698k = false;
		pos808k = true;
		pos909k = false;
		LL_GPIO_ResetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin);   //1
		break;

	case POSITION_909K:
		l_pos0 = false;
		pos110k = false;
		pos200k = false;
		pos300k = false;
		pos402k = false;
		pos499k = false;
		pos604k = false;
		pos698k = false;
		pos808k = false;
		pos909k = true;

		LL_GPIO_SetOutputPin(MUX_CS0_GPIO_Port, MUX_CS0_Pin);   //1
		LL_GPIO_ResetOutputPin(MUX_CS1_GPIO_Port, MUX_CS1_Pin); //0
		LL_GPIO_ResetOutputPin(MUX_CS2_GPIO_Port, MUX_CS2_Pin); //0
		LL_GPIO_SetOutputPin(MUX_CS3_GPIO_Port, MUX_CS3_Pin);   //1
		break;
	}

}

void set_rwb_resistance(float resistance) {
	float remaining_resistance = resistance;

	// Find the closest match in the high_mux array that does not exceed the resistance
	for (h_i = HIGH_MUX_SIZE - 1; h_i >= 0; h_i--) {
		if (resistance >= high_mux[h_i]) {
			set_high_mux((high_mux_pos_t) (h_i + 1)); // Convert index to high_mux_pos_t enum
			remaining_resistance -= high_mux[h_i];
			h_check_bit = true;
			break;
		}
	}
	if (!h_check_bit) {
		set_high_mux(H_POSITION_0);
	}

	// Find the closest match in the low_mux array that does not exceed the remaining resistance
	for (l_i = LOW_MUX_SIZE - 1; l_i >= 0; l_i--) {
		if (remaining_resistance >= low_mux[l_i]) {
			set_low_mux((low_mux_pos_t) (l_i + 1)); // Convert index to low_mux_pos_t enum
			remaining_resistance -= low_mux[l_i];
			l_check_bit = true;
			break;
		}
	}
	if (!l_check_bit) {
		set_low_mux(L_POSITION_0);
	}

	h_check_bit = false;
	l_check_bit = false;

	// Calculate the value for the digital potentiometer based on the remaining resistance
	if (remaining_resistance > 0 && remaining_resistance <= R_AB_WB) {
		digital_pot_value =
				(uint16_t) (1024 * (remaining_resistance / R_AB_WB));
		digital_resistance = remaining_resistance;
		wb_dpt_status = write_rdac(digital_pot_value, AD5293);
	}

}

void phasebit_calculation() {
	input1 = LL_GPIO_IsInputPinSet(INPUT1_GPIO_Port, INPUT1_Pin);
	input2 = LL_GPIO_IsInputPinSet(INPUT2_GPIO_Port, INPUT2_Pin);

	xor = !input1 * input2 + input1 * !input2;
	xor_array[i++] = xor;

	if (i == XOR_SIZE) {
		i = 0;
		xor_mean = calculateMean(&xor_array[0], XOR_SIZE);
		if (xor_mean >= 0.5)
			xor_mean = 1;
		else
			xor_mean = 0;
	}
}

